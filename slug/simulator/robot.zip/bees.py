BEES = 12

class Bee:
    def __init__(self):
        print "Importing a bee"
