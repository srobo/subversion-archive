from bees import Bee

class Face:
    def bee(self):
        bee = Bee()

    def cheese(self):
        print "Cheese"
    
def main(colour, game):
    def face():
        print cheese

    while True:
        yield 1
